
var db;
var request = indexedDB.open('project-cc', 1);
var regNos = [];
var usernames = [];

request.onupgradeneeded = function(event) {
    db = event.target.result;
    var objectStore = db.createObjectStore('users', { keyPath: 'id', autoIncrement: true });
    objectStore.createIndex('username', 'username', { unique: true });
    objectStore.createIndex('regno', 'regno', { unique: true });
};

request.onsuccess = function(event) {
    db = event.target.result;
};

request.onerror = function(event) {
    console.error('Database error: ' + event.target.errorCode);
};


function checkusername(){
    var transaction = db.transaction(['users'], 'readonly');
    var objectStore = transaction.objectStore('users');
    var cursorRequest = objectStore.openCursor();
    usernames = [];
    var username=document.getElementById('user-id').value
    cursorRequest.onsuccess = function(event) {
        var cursor = event.target.result;
        if (cursor) {
            var userData = cursor.value;
            usernames.push(userData.username);
            cursor.continue();
        }
        else{
    if (usernames.includes(username)){
        displaymainpage();
}                   
        } 
    };
    cursorRequest.onerror = function(event) {
        console.error('Error reading users:', event.target.errorCode);
    };   
}
function goback(){
    document.querySelector('.register-now').style.display='none';
    document.querySelector('.login-container').style.display='block'
}
function saveUser(userName,userregno) {
console.log('hi')
            var transaction = db.transaction(['users'], 'readwrite');
            var objectStore = transaction.objectStore('users');
        
            var addUserRequest = objectStore.add({ username: userName, regno: userregno });
        
            addUserRequest.onsuccess = function(event) {
                console.log('User added successfully');
            };
        
            addUserRequest.onerror = function(event) {
                console.error('Error adding user:', event.target.errorCode);
            };
        }
function retrieveData(registerno,username) {
            var transaction = db.transaction(['users'], 'readonly');
            var objectStore = transaction.objectStore('users');
            var cursorRequest = objectStore.openCursor();
            regNos = []; 
            usernames = [];
            cursorRequest.onsuccess = function(event) {
                var cursor = event.target.result;
                if (cursor) {
                    var userData = cursor.value;
                    regNos.push(userData.regno);
                    usernames.push(userData.username);             
                    cursor.continue();
                } else {
                    if (regNos.includes(registerno)){
                        alert('Account already exists. Click "Forgot Username" to know your username.')
                                            }
                                            else if (usernames.includes(username)){
                        alert('Username already exists.')
                                            }
                    else if (!regNos.includes(registerno) && !usernames.includes(username) ){
                        alert('Account created.')
                        saveUser(username,registerno);
                    }
                       }
            };

            cursorRequest.onerror = function(event) {
                console.error('Error reading users:', event.target.errorCode);
            };
        }
function displayUsers() {
            var transaction = db.transaction(['users'], 'readonly');
            var objectStore = transaction.objectStore('users');
            var userTableBody = document.getElementById('userTableBody');
            userTableBody.innerHTML = '';
        
            var cursorRequest = objectStore.openCursor();
        
            cursorRequest.onsuccess = function(event) {
                var cursor = event.target.result;
                if (cursor) {
                    var userData = cursor.value;
                    var row = userTableBody.insertRow();
                    var cell1 = row.insertCell(0);
                    var cell2 = row.insertCell(1);
                    cell1.textContent = userData.username;
                    cell2.textContent = userData.regno;
                    cursor.continue();
                }
            };
        
            cursorRequest.onerror = function(event) {
                console.error('Error reading users:', event.target.errorCode);
            };
        }
function periodvice(dayOfWeekName, currentHour=9, currentMinute=16){
        // dayOfWeekName='Friday'
        // var currentHour=9
        // var currentMinute=16
        var firstPeriod=(currentHour==9&&(currentMinute>=15 && currentMinute<=59))||(currentHour==10&& currentMinute<5)
        var secondPeriod=(currentHour==10&&(currentMinute>=5 && currentMinute<=59))||(currentHour==11&& currentMinute<5)
        var breaktime=(currentHour==11&&(currentMinute>=5 && currentMinute<15))
                var thirdPeriod=(currentHour==11&&(currentMinute>=15 && currentMinute<=59))||(currentHour==12&& currentMinute<10)
                var fourthPeriod=(currentHour==13&&(currentMinute>=0 && currentMinute<45))
                var fifthPeriod=(currentHour==13&&(currentMinute>=45 && currentMinute<=59))||(currentHour==14&& currentMinute<30)
                var sixthPeriod=(currentHour==14&&(currentMinute>=30 && currentMinute<=59))||(currentHour==15&& currentMinute<15)
                var seventhPeriod=(currentHour==15&&(currentMinute>=15 && currentMinute<=59))||(currentHour==16&& currentMinute==0)
                var lunchperiod=(currentHour==12&&(currentMinute>=10 && currentMinute<=59))||(currentHour==13&& currentMinute==0)

                   
    console.log('Today is ' + dayOfWeekName);
        var bodyElement = document.body;
        bodyElement.style.background ='#ecf0f1';
        var period_No=document.querySelector('#period-no');
        var teahername=document.querySelector('#teacher-name')
    var dayname=document.querySelector('#day-name')
        if (firstPeriod){
            period_No.style.opacity='100';
            teahername.style.opacity='100';
            period_No.innerText='1st period'
                document.body.style.backgroundRepeat='no-repeat';
                document.body.style.backgroundSize='100%';
                document.body.style.animation='none';
                 document.body.style.backgroundSize='cover';
            document.body.style.backgroundPosition='center'
            document.body.style.animation='none';
                var pn=document.getElementById('period-name');
                if (dayOfWeekName=='Monday'){
                    dayname.innerText='Monday'
                    pn.innerText='Digital Principles and system design🫱🏻‍🫲🏼';
                    var imageUrl='images/dpsd.png';
                    teahername.innerText='Swarna Mam'
                document.body.style.backgroundImage = `url('${imageUrl}')`;
                }
                else if(dayOfWeekName=='Tuesday'){
                pn.innerText='eee';
                var imageUrl = 'images/eee.webp';
                teahername.innerText='Raja Sir'
                dayname.innerText='Tuesday';
                document.body.style.backgroundImage = `url('${imageUrl}')`;}
                
                else if(dayOfWeekName=='Wednesday'){
                    pn.innerText='Cloud application2️⃣🥼';
                    var imageUrl = 'images/jayasree-mam.jpg';
                    teahername.innerText='Jayasree Mam'
                    dayname.innerText='Wednesday';
                    document.body.style.backgroundImage = `url('${imageUrl}')`;}
                    else if(dayOfWeekName=='Thursday'){
                        pn.innerText='Digital Principles and system design🫱🏻‍🫲🏼';
                        var imageUrl='images/dpsd.png';
                        dayname.innerText='Thursday';
                        teahername.innerText='Swarna Mam'
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
                        else if(dayOfWeekName=='Friday'){
                            dayname.innerText='Friday';
                            pn.innerText='DBMS';
                            var imageUrl = 'images/chandran-sir.jpg';                            
                            teahername.innerText='Chandran Sir'
                            document.body.style.backgroundImage = `url('${imageUrl}')`;}
                            else if (dayOfWeekName=='Saturday'){
                                const imageUrl = 'images/saturday.jpg';
                                period_No.style.opacity='0';
                                teahername.style.opacity='0';
                                dayname.innerText='Saturday';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                var pn=document.getElementById('period-name');
                               
                                pn.innerText='netflix and chill pannu mappi'
                            }
                            else if (dayOfWeekName=='Sunday'){
                                const imageUrl = 'images/saturday.jpg';
                                period_No.style.opacity='0';
                                teahername.style.opacity='0';
                                dayname.innerText='Sunday';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                // document.body.style.scrollBehavior='none'
                                var pn=document.getElementById('period-name');
                                // pn.style.fontFamily='Screamer'
                                pn.innerText='netflix and chill pannu mappi'
                            }
                            
                else{      pn.innerText='';
                    console.log('leaveee')
                }
        }
        else if (breaktime){
            period_No.style.opacity='0';
            teahername.style.opacity='0';
             if (dayOfWeekName=='Saturday'||dayOfWeekName=='Sunday'){
            // var period_No=document.querySelector('#period-no');
            period_No.innerText=''
            const imageUrl = 'images/saturday.jpg';
                                teahername.innerText=''
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                // document.body.style.scrollBehavior='none'
                                var pn=document.getElementById('period-name');
                                // pn.style.fontFamily='Screamer'
                                pn.innerText='netflix and chill pannu mappi'
        }
            else if (dayOfWeekName=='Saturday'){
                dayname.innerText='Saturday'
            }
        else{
            const imageUrl = 'images/intermission.jpg';
            document.body.style.backgroundImage = `url('${imageUrl}')`;
            document.body.style.backgroundRepeat='no-repeat';
            document.body.style.backgroundSize='cover';
            document.body.style.backgroundPosition='center'
            document.body.style.animation='none';
            // document.body.style.scrollBehavior='none'
            var pn=document.getElementById('period-name');
            // pn.style.fontFamily='Screamer'
            pn.innerText=''
            
        }
        }
        else if (secondPeriod){
            period_No.style.opacity='100';
            teahername.style.opacity='100';
            // var period_No=document.querySelector('#period-no');
            period_No.innerText='2nd period'
            document.body.style.backgroundRepeat='no-repeat';
            document.body.style.backgroundSize='100%';
            document.body.style.animation='none';
             document.body.style.backgroundSize='cover';
        document.body.style.backgroundPosition='center'
        document.body.style.animation='none';
            var pn=document.getElementById('period-name');
            // pn.style.fontFamily='Screamer'
            if (dayOfWeekName=='Monday'){
                dayname.innerText='Monday';
                pn.innerText='Digital Principles and system design🫱🏻‍🫲🏼';
                teahername.innerText='Swarna Mam'
                var imageUrl='images/dpsd.png';
            document.body.style.backgroundImage = `url('${imageUrl}')`;
            }
            else if(dayOfWeekName=='Tuesday'){
            pn.innerText='Discrete mathematics';
            dayname.innerText='Tuesday';
            teahername.innerText='A.G.S. Sir'
            var imageUrl = 'images/ags-sir-1.jpeg';
            document.body.style.backgroundImage = `url('${imageUrl}')`;}
            
            else if(dayOfWeekName=='Wednesday'){
                dayname.innerText='Wednesday';
                pn.innerText='Cloud application1️⃣🥼';
                teahername.innerText='Jayasree Mam'
                var imageUrl = 'images/jayasree-mam.jpg';
                document.body.style.backgroundImage = `url('${imageUrl}')`;}
                else if(dayOfWeekName=='Thursday'){
                    dayname.innerText='Thursday';
                    pn.innerText='Digital Principles and system design🫱🏻‍🫲🏼';
                    teahername.innerText='Swarna Mam'
                    var imageUrl='images/dpsd.png';
                    document.body.style.backgroundImage = `url('${imageUrl}')`;}
                    else if(dayOfWeekName=='Friday'){
                        dayname.innerText='Friday';
                        pn.innerText='Data Structures';
                        var imageUrl = 'images/data-structures.jpg';
                        teahername.innerText='Sivasakthi Mam'
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
                        else if (dayOfWeekName=='Saturday'){
                            const imageUrl = 'images/saturday.jpg';
                            period_No.style.opacity='0';
            teahername.style.opacity='0';
                            document.body.style.backgroundImage = `url('${imageUrl}')`;
                            document.body.style.backgroundRepeat='no-repeat';
                            document.body.style.backgroundSize='cover';
                            document.body.style.backgroundPosition='center'
                            document.body.style.animation='none';
                            // document.body.style.scrollBehavior='none'
                            var pn=document.getElementById('period-name');
                            // pn.style.fontFamily='Screamer'
                            pn.innerText='netflix and chill pannu mappi'
                        }
                        else if (dayOfWeekName=='Sunday'){
                            dayname.innerText='Sunday';
                            const imageUrl = 'images/saturday.jpg';
                            period_No.style.opacity='0';
            teahername.style.opacity='0';
                            document.body.style.backgroundImage = `url('${imageUrl}')`;
                            document.body.style.backgroundRepeat='no-repeat';
                            document.body.style.backgroundSize='cover';
                            document.body.style.backgroundPosition='center'
                            document.body.style.animation='none';
                            // document.body.style.scrollBehavior='none'
                            var pn=document.getElementById('period-name');
                            // pn.style.fontFamily='Screamer'
                            pn.innerText='netflix and chill pannu mappi'
                        }
                        else{      pn.innerText='';
                console.log('leaveee')
            }
    } 
        // }
        else if (thirdPeriod){
            period_No.style.opacity='100';
            teahername.style.opacity='100';
            // var period_No=document.querySelector('#period-no');
            period_No.innerText='3rd period'
            document.body.style.backgroundRepeat='no-repeat';
            document.body.style.backgroundSize='100%';
            document.body.style.animation='none';
             document.body.style.backgroundSize='cover';
        document.body.style.backgroundPosition='center'
        document.body.style.animation='none';
            var pn=document.getElementById('period-name');
            // pn.style.fontFamily='Screamer'
            if (dayOfWeekName=='Monday'){
                dayname.innerText='Monday';
                pn.innerText='DBMS';
                var imageUrl = 'images/chandran-sir.jpg';
                            teahername.innerText='Chandran Sir'
                            document.body.style.backgroundImage = `url('${imageUrl}')`;
            }
            else if(dayOfWeekName=='Tuesday'){
                dayname.innerText='Tuesday';
                pn.innerText='eee';
                var imageUrl = 'images/eee.webp';
                teahername.innerText='Raja Sir'
                document.body.style.backgroundImage = `url('${imageUrl}')`;}
            
            else if(dayOfWeekName=='Wednesday'){
                dayname.innerText='Wednesday';
                pn.innerText='Discrete mathematics';
           var imageUrl = 'images/ags-sir-1.jpeg';
            teahername.innerText='A.G.S. Sir'
            document.body.style.backgroundImage = `url('${imageUrl}')`;}
    
                else if(dayOfWeekName=='Thursday'){
                    dayname.innerText='Thursday';
                    pn.innerText='eee';
                var imageUrl = 'images/eee.webp';
                teahername.innerText='Raja Sir'
                document.body.style.backgroundImage = `url('${imageUrl}')`;}
    
                    else if(dayOfWeekName=='Friday'){
                        dayname.innerText='Friday';
                        pn.innerText='eee';
                var imageUrl = 'images/eee.webp';
                teahername.innerText='Raja Sir'
                document.body.style.backgroundImage = `url('${imageUrl}')`;}
                else if (dayOfWeekName=='Saturday'){
                    const imageUrl = 'images/saturday.jpg';
                    dayname.innerText='Saturday';
                    period_No.style.opacity='0';
            teahername.style.opacity='0';
                    document.body.style.backgroundImage = `url('${imageUrl}')`;
                    document.body.style.backgroundRepeat='no-repeat';
                    document.body.style.backgroundSize='cover';
                    document.body.style.backgroundPosition='center'
                    document.body.style.animation='none';
                    // document.body.style.scrollBehavior='none'
                    var pn=document.getElementById('period-name');
                    // pn.style.fontFamily='Screamer'
                    pn.innerText='netflix and chill pannu mappi'
                }
                else if (dayOfWeekName=='Sunday'){
                    dayname.innerText='Sunday';
                    const imageUrl = 'images/saturday.jpg';
                    period_No.style.opacity='0';
            teahername.style.opacity='0';
                    document.body.style.backgroundImage = `url('${imageUrl}')`;
                    document.body.style.backgroundRepeat='no-repeat';
                    document.body.style.backgroundSize='cover';
                    document.body.style.backgroundPosition='center'
                    document.body.style.animation='none';
                    // document.body.style.scrollBehavior='none'
                    var pn=document.getElementById('period-name');
                    // pn.style.fontFamily='Screamer'
                    pn.innerText='netflix and chill pannu mappi'
                }
            else{
                console.log('leaveee')
            }
    }  else if (fourthPeriod){
        period_No.style.opacity='100';
        teahername.style.opacity='100';
        // var period_No=document.querySelector('#period-no');
        period_No.innerText='4th period'
        document.body.style.backgroundRepeat='no-repeat';
        document.body.style.backgroundSize='100%';
        document.body.style.animation='none';
         document.body.style.backgroundSize='cover';
    document.body.style.backgroundPosition='center'
    document.body.style.animation='none';
        var pn=document.getElementById('period-name');
        // pn.style.fontFamily='Screamer'
        if (dayOfWeekName=='Monday'){
            dayname.innerText='Monday';
            pn.innerText='Cloud application';
            var imageUrl = 'images/jayasree-mam.jpg';
            teahername.innerText='Jayasree Mam'
            document.body.style.backgroundImage = `url('${imageUrl}')`;
        }
        else if(dayOfWeekName=='Tuesday'){
            dayname.innerText='Tuesday';
            pn.innerText='Data Structures';
            teahername.innerText='Sivasakthi Mam'
                        var imageUrl = 'images/data-structures.jpg';
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
        
        else if(dayOfWeekName=='Wednesday'){
            pn.innerText='DBMS';
            dayname.innerText='Wednesday';
            teahername.innerText='Chandran Sir'
            var imageUrl = 'images/chandran-sir.jpg';
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
    
            else if(dayOfWeekName=='Thursday'){
                dayname.innerText='Thursday';
                pn.innerText='Data Structures';
                teahername.innerText='Sivasakthi Mam'
                        var imageUrl = 'images/data-structures.jpg';
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
                else if(dayOfWeekName=='Friday'){
                    dayname.innerText='Friday';
                    pn.innerText='Discrete mathematics';
                    teahername.innerText='A.G.S. Sir'
           var imageUrl = 'images/ags-sir-1.jpeg';
            document.body.style.backgroundImage = `url('${imageUrl}')`;}
            else if (dayOfWeekName=='Saturday'){
                dayname.innerText='Saturday';
                const imageUrl = 'images/saturday.jpg';
                period_No.style.opacity='0';
                teahername.style.opacity='0';
                document.body.style.backgroundImage = `url('${imageUrl}')`;
                document.body.style.backgroundRepeat='no-repeat';
                document.body.style.backgroundSize='cover';
                document.body.style.backgroundPosition='center'
                document.body.style.animation='none';
                // document.body.style.scrollBehavior='none'
                var pn=document.getElementById('period-name');
                // pn.style.fontFamily='Screamer'
                pn.innerText='netflix and chill pannu mappi'
            }
            else if(dayOfWeekName=='Sunday'){
                dayname.innerText='Sunday';
                const imageUrl = 'images/saturday.jpg';
                period_No.style.opacity='0';
                teahername.style.opacity='0';
                document.body.style.backgroundImage = `url('${imageUrl}')`;
                document.body.style.backgroundRepeat='no-repeat';
                document.body.style.backgroundSize='cover';
                document.body.style.backgroundPosition='center'
                document.body.style.animation='none';
                // document.body.style.scrollBehavior='none'
                var pn=document.getElementById('period-name');
                // pn.style.fontFamily='Screamer'
                pn.innerText='netflix and chill pannu mappi'
            }
        else{
            console.log('leaveee')
        }
    } 
    else if (fifthPeriod){
        period_No.style.opacity='100';
        teahername.style.opacity='100';
        // var period_No=document.querySelector('#period-no');
        period_No.innerText='5th period'
        document.body.style.backgroundRepeat='no-repeat';
        document.body.style.backgroundSize='100%';
        document.body.style.animation='none';
         document.body.style.backgroundSize='cover';
    document.body.style.backgroundPosition='center'
    document.body.style.animation='none';
        var pn=document.getElementById('period-name');
        // pn.style.fontFamily='Screamer'
        if (dayOfWeekName=='Monday'){
            dayname.innerText='Monday';
            pn.innerText='Discrete mathematics';
            teahername.innerText='A.G.S. Sir'
            var imageUrl = 'images/ags-sir-1.jpeg';
            document.body.style.backgroundImage = `url('${imageUrl}')`;
        }
        else if(dayOfWeekName=='Tuesday'){
            dayname.innerText='Tuesday';
            pn.innerText='Data Structures3️⃣🥼';
            teahername.innerText='Sivasakthi Mam'
                        var imageUrl = 'images/data-structures.jpg';
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
        
        else if(dayOfWeekName=='Wednesday'){
            dayname.innerText='Wednesday';
            pn.innerText='Data Structures';
            var imageUrl = 'images/data-structures.jpg';
            teahername.innerText='Sivasakthi Mam'
            document.body.style.backgroundImage = `url('${imageUrl}')`;}
    
            else if(dayOfWeekName=='Thursday'){
                dayname.innerText='Thurday';
                pn.innerText='Digital Principles and system design3️⃣🥼';
                teahername.innerText='Deborah Mam'
                    var imageUrl = 'images/dpsd.png';
                    document.body.style.backgroundImage = `url('${imageUrl}')`;}
                else if(dayOfWeekName=='Friday'){
                    dayname.innerText='Friday';
                    pn.innerText='DBMS3️⃣🥼';
                    var imageUrl = 'images/chandran-sir.jpg';
                            teahername.innerText='Chandran Sir'
                            document.body.style.backgroundImage = `url('${imageUrl}')`;}
                            else if (dayOfWeekName=='Saturday'){
                                dayname.innerText='Saturday';
                                const imageUrl = 'images/saturday.jpg';
                                period_No.style.opacity='0';
            teahername.style.opacity='0';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                // document.body.style.scrollBehavior='none'
                                var pn=document.getElementById('period-name');
                                // pn.style.fontFamily='Screamer'
                                pn.innerText='netflix and chill pannu mappi'
                            }
                            else if (dayOfWeekName=='Sunday'){
                                dayname.innerText='Sunday';
                                const imageUrl = 'images/saturday.jpg';
                                period_No.style.opacity='0';
            teahername.style.opacity='0';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                // document.body.style.scrollBehavior='none'
                                var pn=document.getElementById('period-name');
                                // pn.style.fontFamily='Screamer'
                                pn.innerText='netflix and chill pannu mappi'
                            }
        else{
            console.log('leaveee')
        }
    } 
    else if (sixthPeriod){

        period_No.style.opacity='100';
        teahername.style.opacity='100';
        // var period_No=document.querySelector('#period-no');
        period_No.innerText='6th period'
        document.body.style.backgroundRepeat='no-repeat';
        document.body.style.backgroundSize='100%';
        document.body.style.animation='none';
         document.body.style.backgroundSize='cover';
    document.body.style.backgroundPosition='center'
    document.body.style.animation='none';
        var pn=document.getElementById('period-name');
        // pn.style.fontFamily='Screamer'
        if (dayOfWeekName=='Monday'){
            dayname.innerText='Monday';
            pn.innerText='Human Values🫱🏻‍🫲🏼';
            teahername.innerText='Madhura Mam'
            var imageUrl = 'images/human-values.png';
            document.body.style.backgroundImage = `url('${imageUrl}')`;
        }
        else if(dayOfWeekName=='Tuesday'){
            dayname.innerText='Tuesday';
            pn.innerText='Data Structures2️⃣🥼';
            teahername.innerText='Sivasakthi Mam'
                        var imageUrl = 'images/data-structures.jpg';
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
        
        else if(dayOfWeekName=='Wednesday'){
            dayname.innerText='Wednesday';
            pn.innerText='Cloud application';
            teahername.innerText='Jayasree Mam'
            var imageUrl = 'images/jayasree-mam.jpg';
                document.body.style.backgroundImage = `url('${imageUrl}')`;}
            else if(dayOfWeekName=='Thursday'){
                dayname.innerText='Thursday';
                pn.innerText='Digital Principles and system design2️⃣🥼';
                teahername.innerText='Deborah Mam'
                    var imageUrl = 'images/dpsd.png';
                    document.body.style.backgroundImage = `url('${imageUrl}')`;}
                else if(dayOfWeekName=='Friday'){
                    dayname.innerText='Friday';
                    pn.innerText='DBMS2️⃣🥼';
                    teahername.innerText='Chandran Sir'
                    var imageUrl = 'images/chandran-sir.jpg';
                            document.body.style.backgroundImage = `url('${imageUrl}')`;}
                            else if (dayOfWeekName=='Saturday'){
                                dayname.innerText='Saturday';
                                const imageUrl = 'images/saturday.jpg';
                                period_No.style.opacity='0';
            teahername.style.opacity='0';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                var pn=document.getElementById('period-name');
                                pn.innerText='netflix and chill pannu mappi'
                            }
                            else if(dayOfWeekName=='Sunday'){
                                dayname.innerText='Sunday';
                                const imageUrl = 'images/saturday.jpg';
                                period_No.style.opacity='0';
            teahername.style.opacity='0';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                var pn=document.getElementById('period-name');
                                pn.innerText='netflix and chill pannu mappi'
                            }
        else{
            console.log('leaveee')
        }
    } 
    else if (seventhPeriod){
        period_No.style.opacity='100';
        teahername.style.opacity='100';
        period_No.innerText='7th period'
        document.body.style.backgroundRepeat='no-repeat';
        document.body.style.backgroundSize='100%';
        document.body.style.animation='none';
         document.body.style.backgroundSize='cover';
    document.body.style.backgroundPosition='center'
    document.body.style.animation='none';
        var pn=document.getElementById('period-name');
        if (dayOfWeekName=='Monday'){
            dayname.innerText='Monday';
            pn.innerText='Human Values🫱🏻‍🫲🏼';
            teahername.innerText='Madhura Mam'
            var imageUrl = 'images/human-values.png';
            document.body.style.backgroundImage = `url('${imageUrl}')`;
        }
        else if(dayOfWeekName=='Tuesday'){
            dayname.innerText='Tuesday';
            pn.innerText='Data Structures1️⃣🥼';
            teahername.innerText='Sivasakthi Mam'
                        var imageUrl = 'images/data-structures.jpg';
                        document.body.style.backgroundImage = `url('${imageUrl}')`;}
        
        else if(dayOfWeekName=='Wednesday'){
            dayname.innerText='Wednesday';
            pn.innerText='DBMS';
            teahername.innerText='Chandran Sir'
            var imageUrl = 'images/chandran-sir.jpg';
                            document.body.style.backgroundImage = `url('${imageUrl}')`;}
    
            else if(dayOfWeekName=='Thursday'){
                dayname.innerText='Thursday';
                pn.innerText='Digital Principles and system design1️⃣🥼';
                teahername.innerText='Deborah Mam'
                    var imageUrl = 'images/dpsd.png';
                    document.body.style.backgroundImage = `url('${imageUrl}')`;}
                else if(dayOfWeekName=='Friday'){
                    dayname.innerText='Friday';
                    pn.innerText='DBMS1️⃣🥼';
                    teahername.innerText='Chandran Sir'
                    var imageUrl = 'images/chandran-sir.jpg';
                            document.body.style.backgroundImage = `url('${imageUrl}')`;}
                            else if (dayOfWeekName=='Saturday'){
                                const imageUrl = 'images/saturday.jpg';
                                dayname.innerText='Saturday';
                                period_No.style.opacity='0';
            teahername.style.opacity='0';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                var pn=document.getElementById('period-name');
                                pn.innerText='netflix and chill pannu mappi'
                            }
                            else if(dayOfWeekName=='Sunday'){
                                dayname.innerText='Sunday';
                                const imageUrl = 'images/saturday.jpg';
                                period_No.style.opacity='0';
            teahername.style.opacity='0';
                                document.body.style.backgroundImage = `url('${imageUrl}')`;
                                document.body.style.backgroundRepeat='no-repeat';
                                document.body.style.backgroundSize='cover';
                                document.body.style.backgroundPosition='center'
                                document.body.style.animation='none';
                                
                                
                                var pn=document.getElementById('period-name');
                                // pn.style.fontFamily='Screamer'
                                pn.innerText='netflix and chill pannu mappi'
                            }
        else{
            console.log('leaveee')
        }
    } 
        
        else if(lunchperiod){
            
            if (dayOfWeekName!='Saturday'&&dayOfWeekName!='Sunday'){
                period_No.style.opacity='0';
            teahername.style.opacity='0';
            const imageUrl = 'images/lunch.png';
            document.body.style.backgroundImage = `url('${imageUrl}')`;
            document.body.style.backgroundRepeat='no-repeat';
            document.body.style.backgroundSize='cover';
            document.body.style.backgroundPosition='center'
            document.body.style.animation='none';
            var pn=document.getElementById('period-name');
            pn.innerText='Innaiku Oru pudi'
            }
            else if (dayOfWeekName=='Saturday'||dayOfWeekName=='Sunday'){
                const imageUrl = 'images/saturday.jpg';
                period_No.style.opacity='0';
            teahername.style.opacity='0';
                document.body.style.backgroundImage = `url('${imageUrl}')`;
                document.body.style.backgroundRepeat='no-repeat';
                document.body.style.backgroundSize='cover';
                document.body.style.backgroundPosition='center'
                document.body.style.animation='none';
                var pn=document.getElementById('period-name');
                pn.innerText='netflix and chill pannu mappi'
            }
        }
        
    
}
function showStoredUsers(){
    document.querySelector('.login-container').style.display='none'
    document.querySelector('.forgot-username').style.display='block';
    document.body.style.animation='none'
    document.body.style.backgroundImage='none'
    displayUsers();
}          
function showRegisterForm(){
    var login_in_button=document.querySelector('.login-container')
    var register_now=document.querySelector('.register-now')
        if(login_in_button){
            login_in_button.style.display='none';
            register_now.style.display='block';}
        
        else {
            
        }

    }    
function displaymainpage(){
    var login_in_button=document.querySelector('.login-container')
        if(login_in_button){
    login_in_button.style.display='none';
            var check=document.querySelector('#logo-sticker')
            check.innerText='CAMPUS CALENDAR'
            function updateClock() {
    var currentDateTime = new Date();
var dayOfWeekNumber = currentDateTime.getDay();
// var currentHour = currentTime.getHours();
//     var currentMinute = currentTime.getMinutes();

var daysOfWeek = [ 'Sunday','Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
var dayOfWeekName= daysOfWeek[dayOfWeekNumber];
var currentHour=9
        var currentMinute=16
        var firstPeriod=(currentHour==9&&(currentMinute>=15 && currentMinute<=59))||(currentHour==10&& currentMinute<5)
        var secondPeriod=(currentHour==10&&(currentMinute>=5 && currentMinute<=59))||(currentHour==11&& currentMinute<5)
        var breaktime=(currentHour==11&&(currentMinute>=5 && currentMinute<15))
                var thirdPeriod=(currentHour==11&&(currentMinute>=15 && currentMinute<=59))||(currentHour==12&& currentMinute<10)
                var fourthPeriod=(currentHour==13&&(currentMinute>=0 && currentMinute<45))
                var fifthPeriod=(currentHour==13&&(currentMinute>=45 && currentMinute<=59))||(currentHour==14&& currentMinute<30)
                var sixthPeriod=(currentHour==14&&(currentMinute>=30 && currentMinute<=59))||(currentHour==15&& currentMinute<15)
                var seventhPeriod=(currentHour==15&&(currentMinute>=15 && currentMinute<=59))||(currentHour==16&& currentMinute==0)
                var lunchperiod=(currentHour==12&&(currentMinute>=10 && currentMinute<=59))||(currentHour==13&& currentMinute==0)
                var checker;
if (firstPeriod){
    checker="first";
}
else if(secondPeriod){
    checker="second";
}else if(breaktime){
    checker="break";
}else if(thirdPeriod){
    checker="third";
}else if(lunchperiod){
    checker="lunch";
}else if(fourthPeriod){
    checker="fourth";
}else if(fifthPeriod){
    checker="fifth";
}else if(sixthPeriod){
    checker="sixth";
}else if(seventhPeriod){
    checker="seventh";
}
const periodTimetable = {
    "first": { hours: 9, minutes: 16 },
    "second": { hours: 10, minutes:15 },
    "break": { hours: 11, minutes: 10 },
    "third": { hours: 11, minutes: 16 },
    "lunch": { hours: 12, minutes: 11 },
    "fourth": { hours: 13, minutes: 1 },
    "fifth": { hours: 13, minutes: 46 },
    "sixth": { hours: 14, minutes: 31 },
    "seventh": { hours: 15, minutes: 16 }
  };
  var test = ['first', 'second', 'break', 'third', 'lunch', 'fourth', 'fifth', 'sixth', 'seventh'];
console.log(checker)
  var testing = test.indexOf(checker)
  console.log(testing)
console.log('Today is ' + dayOfWeekName);
periodvice(dayOfWeekName,9,16);
document.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowRight') {
            console.log(dayOfWeekNumber)
            console.log('Right swipe!');                
            dayOfWeekNumber = (dayOfWeekNumber+1)%7;  
            dayOfWeekName= daysOfWeek[dayOfWeekNumber];
            periodvice(dayOfWeekName,9,16);
}
else if(e.key === 'ArrowLeft')
{	    console.log(dayOfWeekNumber)
            console.log('Left swipe!');                
            dayOfWeekNumber = (dayOfWeekNumber+6)%7;  
            dayOfWeekName= daysOfWeek[dayOfWeekNumber];
            periodvice(dayOfWeekName,9,16);	
} 
else if(e.key === 'ArrowDown')
{
            console.log('Down Swipe!');
            testing = (testing + 1)%9;
            console.log(testing)
            dummystring = test[testing];
            console.log(dummystring)
            console.log(periodTimetable[dummystring].hours)
            console.log(periodTimetable[dummystring].minutes)
            
            periodvice(dayOfWeekName, periodTimetable[dummystring].hours, periodTimetable[dummystring].minutes)
}
else if(e.key === 'ArrowUp')
{
            console.log('Up Swipe!');
            testing = (testing + 8)%9;
            dummystring = test[testing];
            periodvice(dayOfWeekName, periodTimetable[dummystring].hours, periodTimetable[dummystring].minutes)
}
    });
    }
updateClock();
setInterval(updateClock, 60000);
            
        }}
function checkInputRange() {
    var inputElement = document.getElementById('regno');
 var inputValue = parseInt(inputElement.value);
    var minRange = 221191101055;
    var maxRange = 221191101107;
    if (!isNaN(inputValue) && inputValue >= minRange && inputValue <= maxRange|| inputValue==221191101783) {
        var registerno = document.getElementById('regno').value;
            var username=document.getElementById('username').value
        retrieveData(registerno,username);
         }
         else {
            alert('Invalid Register No');

    }}
    